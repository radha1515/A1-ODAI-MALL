
console.log("A1 ODAI MALL app loaded!");
